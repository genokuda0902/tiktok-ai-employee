import copy,hashlib,os,subprocess,tempfile,unittest
from pathlib import Path
from cursor_guide import GENRES,POLICY,SAFE,PALETTE,draw_overlay,position,render,validate

HASH='a'*64
INFO={'frames':691,'duration':23.033333}
def fixture(g='ai'):
    return {'policy':POLICY,'asset_approval':'private_review_only','source_sha256':HASH,'genre':g,'start_frame':429,'end_frame':519,'waypoints':[[395,722],[595,722],[840,1010]]}

class CursorGuideTests(unittest.TestCase):
    def test_all_genres(self):
        for g in GENRES:self.assertEqual(validate(fixture(g),HASH,INFO)[0],429)
    def test_palette_for_all_genres(self):self.assertEqual(set(GENRES),set(PALETTE))
    def test_no_missing_approval(self):
        m=fixture();m.pop('asset_approval')
        with self.assertRaises(ValueError):validate(m,HASH,INFO)
    def test_no_publication_claim(self):
        m=fixture();m['policy']='PUBLICATION_APPROVED'
        with self.assertRaises(ValueError):validate(m,HASH,INFO)
    def test_hash_gate(self):
        with self.assertRaises(ValueError):validate(fixture(),'b'*64,INFO)
    def test_no_subtitle_roi(self):
        m=fixture();m['waypoints'][2]=[850,1550]
        with self.assertRaises(ValueError):validate(m,HASH,INFO)
    def test_no_unbounded_window(self):
        m=fixture();m['end_frame']=690
        with self.assertRaises(ValueError):validate(m,HASH,INFO)
    def test_no_duplicate_point(self):
        m=fixture();m['waypoints'][1]=m['waypoints'][0]
        with self.assertRaises(ValueError):validate(m,HASH,INFO)
    def test_static_and_motion_positions(self):
        p=fixture()['waypoints']
        self.assertEqual(position(0.05,p)[0],tuple(p[0]));self.assertEqual(position(.50,p)[0],tuple(p[1]));self.assertEqual(position(.92,p)[0],tuple(p[2]))
        self.assertIsNone(position(.30,p)[1])
    def test_transparent_caption_and_header(self):
        im=draw_overlay(30,90,fixture()['waypoints'],PALETTE['ai'])
        self.assertEqual(im.getpixel((500,1600))[3],0)
        self.assertEqual(im.getpixel((500,120))[3],0)
        self.assertGreater(im.getpixel((round(position(30/89,fixture()["waypoints"])[0][0])+10,730))[3],0)
    @unittest.skipUnless(os.environ.get('RUN_MEDIA_SMOKE')=='1','RUN_MEDIA_SMOKE=1')
    def test_synthetic_av(self):
        with tempfile.TemporaryDirectory() as td:
            src=Path(td)/'src.mp4';dst=Path(td)/'out.mp4'
            subprocess.run(['ffmpeg','-y','-v','error','-f','lavfi','-i','color=c=0x122233:s=1080x1920:r=30:d=2','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=2','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p','-c:a','aac','-metadata:s:a:0','language=jpn','-t','2',str(src)],check=True)
            m=fixture();m['source_sha256']=hashlib.sha256(src.read_bytes()).hexdigest();m['start_frame']=6;m['end_frame']=36
            qa=render(src,dst,m);self.assertEqual(qa['frames'],60);self.assertEqual(qa['effect_frames'],30)
if __name__=='__main__':unittest.main()
