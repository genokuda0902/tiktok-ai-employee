#!/usr/bin/env python3
"""Review-only, 10-genre mouse-guidance overlay for approved/private video.

Synthetic cursor is a visual illustration, NOT a screen recording or a proof of clicks.
Fail closed on input SHA and approval; preserve existing Japanese narration and captions.
"""
import argparse, hashlib, json, math, subprocess, tempfile
from pathlib import Path
from PIL import Image, ImageDraw

GENRES=('ai','business','money','learning','health','food','travel','beauty','career','life')
POLICY='HUMAN_REVIEW/PUBLICATION_NOT_APPROVED'
PALETTE={'ai':'#24E1D3','business':'#52B9FF','money':'#F3CB60','learning':'#A3DD7A','health':'#7BD9CF','food':'#FFB16C','travel':'#7DBDFF','beauty':'#EE9FCF','career':'#92C3FF','life':'#C5C1FF'}
SAFE=(270,620,940,1170)

def run(args):
    p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode: raise RuntimeError(f'{args[0]} exit={p.returncode}: {p.stderr.decode("utf-8","replace")[-1200:]}')
    return p.stdout

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def audio_hash(path):
    return hashlib.sha256(run(['ffmpeg','-v','error','-i',str(path),'-map','0:a:0','-c:a','copy','-f','adts','-'])).hexdigest()

def probe(path):
    d=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))
    v=[s for s in d['streams'] if s['codec_type']=='video'];a=[s for s in d['streams'] if s['codec_type']=='audio']
    if len(v)!=1 or len(a)!=1 or len(d['streams'])!=2:raise ValueError('require exactly one video and one audio stream')
    if (v[0]['codec_name'],v[0]['width'],v[0]['height'],v[0]['avg_frame_rate'])!=('h264',1080,1920,'30/1'):raise ValueError('require H264 1080x1920 30fps')
    if (a[0]['codec_name'],a[0]['sample_rate'],a[0].get('tags',{}).get('language'))!=('aac','48000','jpn'):raise ValueError('require Japanese-tagged AAC 48kHz')
    return {'frames':int(v[0]['nb_frames']),'duration':float(d['format']['duration'])}

def validate(m,source_hash,info):
    if set(m)!={'policy','asset_approval','source_sha256','genre','start_frame','end_frame','waypoints'}:raise ValueError('unexpected or missing manifest keys')
    if m['policy']!=POLICY or m['asset_approval']!='private_review_only' or m['source_sha256']!=source_hash:raise ValueError('source hash/approval gate failed')
    if m['genre'] not in GENRES:raise ValueError('unsupported genre')
    st,en=m['start_frame'],m['end_frame']
    if type(st)!=int or type(en)!=int or not (0<=st<en<=info['frames'] and en-st<=120):raise ValueError('unsafe time window')
    p=m['waypoints']
    if not isinstance(p,list) or len(p)!=3:raise ValueError('exactly 3 proof points required')
    for xy in p:
        if not isinstance(xy,list) or len(xy)!=2 or any(type(z)!=int for z in xy):raise ValueError('waypoints must be integer pairs')
        if not (SAFE[0]<=xy[0]<=SAFE[2] and SAFE[1]<=xy[1]<=SAFE[3]):raise ValueError('cursor outside content-only safe ROI')
    if len(set(tuple(x) for x in p))!=3:raise ValueError('duplicate cursor points')
    return st,en,p

def smooth(t):
    t=max(0,min(1,t));return t*t*(3-2*t)

def position(q,pts):
    # 3 staged proof stops, with a dwell at each click point.
    if q<0.22:return tuple(pts[0]),0
    if q<0.38:
        t=smooth((q-.22)/.16);return tuple(pts[0][j]*(1-t)+pts[1][j]*t for j in range(2)),None
    if q<0.58:return tuple(pts[1]),1
    if q<0.74:
        t=smooth((q-.58)/.16);return tuple(pts[1][j]*(1-t)+pts[2][j]*t for j in range(2)),None
    return tuple(pts[2]),2

def draw_overlay(index,total,points,color):
    q=index/max(1,total-1);(x,y),dwell=position(q,points)
    x,y=round(x),round(y)
    im=Image.new('RGBA',(1080,1920),(0,0,0,0));d=ImageDraw.Draw(im)
    # Original vector cursor, dark outline, high-contrast white fill.
    path=[(x,y),(x+3,y+53),(x+17,y+42),(x+29,y+68),(x+42,y+61),(x+30,y+35),(x+48,y+35)]
    shadow=[(a+4,b+5) for a,b in path]
    d.polygon(shadow,fill=(0,0,0,130));d.polygon(path,fill=(247,253,255,245))
    d.line(path+[path[0]],fill=(1,23,43,255),width=4,joint='curve')
    # Brief click ring only at each stationary point, never on the subtitle area.
    if dwell is not None:
        local=(q if dwell==0 else (q-.38 if dwell==1 else q-.74))
        pulse=local%0.20
        r=20+int(46*min(1,pulse/.2));alpha=int(175*(1-min(1,pulse/.2)))
        rgb=tuple(bytes.fromhex(color[1:]))
        d.ellipse((x-r,y-r,x+r,y+r),outline=(*rgb,alpha),width=5)
    return im

def render(src,dst,manifest,qa_path=None):
    src=Path(src);dst=Path(dst);info=probe(src);src_hash=sha256(src)
    st,en,pts=validate(manifest,src_hash,info)
    dst.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='cursor_guide_') as td:
        folder=Path(td)
        for i in range(en-st):draw_overlay(i,en-st,pts,PALETTE[manifest['genre']]).save(folder/f'frame_{i:03d}.png')
        filt=f'[1:v]format=rgba,setpts=PTS+{st}/30/TB[ov];[0:v][ov]overlay=0:0:eof_action=pass:repeatlast=0:shortest=0:format=auto[v]'
        run(['ffmpeg','-y','-v','error','-i',str(src),'-framerate','30','-i',str(folder/'frame_%03d.png'),'-filter_complex',filt,'-map','[v]','-map','0:a:0','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-frames:v',str(info['frames']),'-c:a','copy','-movflags','+faststart',str(dst)])
    out=probe(dst)
    if out['frames']!=info['frames'] or abs(out['duration']-info['duration'])>.04:raise RuntimeError('frame or duration drift')
    if audio_hash(src)!=audio_hash(dst):raise RuntimeError('audio stream changed')
    run(['ffmpeg','-v','error','-xerror','-i',str(dst),'-map','0:v:0','-f','null','-'])
    run(['ffmpeg','-v','error','-xerror','-i',str(dst),'-map','0:a:0','-f','null','-'])
    qa={'policy':POLICY,'source_sha256':src_hash,'output_sha256':sha256(dst),'audio_adts_sha256':audio_hash(dst),'frames':out['frames'],'duration':out['duration'],'effect_frames':en-st,'genre':manifest['genre'],'full_av_decode':'PASS','speech_semantic_match':'NOT_TESTED','phone_playback':'NOT_TESTED','reference_parity':'NOT_TESTED'}
    if qa_path:Path(qa_path).write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
    return qa

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',required=True);ap.add_argument('--output',required=True);ap.add_argument('--manifest',required=True);ap.add_argument('--qa')
    a=ap.parse_args();print(json.dumps(render(a.source,a.output,json.loads(Path(a.manifest).read_text(encoding='utf-8')),a.qa),ensure_ascii=False,indent=2))
