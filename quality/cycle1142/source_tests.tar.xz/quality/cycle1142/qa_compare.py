#!/usr/bin/env python3
"""Compare two local private MP4s; do not upload them to GitHub."""
import argparse
import json
import subprocess
import numpy as np
from pathlib import Path

def rgb_region(path,crop,scale):
    x,y,w,h=crop;sw,sh=scale
    p=subprocess.run(['ffmpeg','-v','error','-i',str(path),'-vf',f'crop={w}:{h}:{x}:{y},scale={sw}:{sh}',
        '-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True)
    a=np.frombuffer(p.stdout,dtype=np.uint8)
    return a.reshape((-1,sh,sw,3))

def compare(a,b):
    return np.abs(a.astype(np.int16)-b.astype(np.int16)).mean(axis=(1,2,3))

def main(src,out,path):
    # Full-frame sequence of all 691 caption frames, downsampled 4x.
    s=rgb_region(src,(0,1490,1080,350),(270,88));t=rgb_region(out,(0,1490,1080,350),(270,88))
    caption=compare(s,t)
    # Full content panel, sampled at every frame, downsampled 4x.
    s=rgb_region(src,(55,170,970,800),(243,200));t=rgb_region(out,(55,170,970,800),(243,200))
    visual=compare(s,t)
    changes=np.where(visual>2.0)[0]
    data={'frames':len(caption),'caption_roi':'y1490..1839, all frames, downsampled 4x',
          'caption_mae_max_255':round(float(caption.max()),4),'caption_mae_p95_255':round(float(np.percentile(caption,95)),4),
          'content_change_frames_over_2_mae':int(len(changes)),'content_change_frame_min':int(changes.min()) if len(changes) else None,
          'content_change_frame_max':int(changes.max()) if len(changes) else None,
          'B_stage_mean_mae':round(float(visual[182:207].mean()),4),'C_stage_mean_mae':round(float(visual[207:218].mean()),4),
          'outside_stage_max_mae':round(float(np.r_[visual[:182],visual[219:]].max()),4),
          'caption_semantic_match':'NOT_VERIFIED','reference_v33_comparison':'NOT_AVAILABLE'}
    Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(data,ensure_ascii=False,indent=2))
    if data['caption_mae_max_255']>1.5:raise RuntimeError('caption visual drift above threshold')
    if data['outside_stage_max_mae']>2:raise RuntimeError('unexpected change outside effect window')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ('source','output','report'):p.add_argument('--'+k,required=True)
    a=p.parse_args();main(a.source,a.output,a.report)
