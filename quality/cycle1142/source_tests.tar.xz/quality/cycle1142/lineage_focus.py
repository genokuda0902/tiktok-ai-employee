#!/usr/bin/env python3
"""Private-review-only spreadsheet data-lineage cue, reusable across 10 genre manifests.

Visual QA repair: when B5 is selected, do not falsely show the C-column formula.
Animated per-column arithmetic evidence stays within the audited content panel;
never modifies the narration or baked Japanese subtitle region. This is a
reimplementation, not original v33 source. Never auto-post or merge.
"""
import argparse
import hashlib
import json
import math
import re
import subprocess
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

POLICY = 'HUMAN_REVIEW/PUBLICATION_NOT_APPROVED'
GENRES = ('ai','business','money','learning','health','food','travel','beauty','career','life')
FONT = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
FONT_REG = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
ROI = (55, 170, 970, 800)


def cmd(argv, binary=False):
    p = subprocess.run(argv, capture_output=True, text=not binary)
    if p.returncode:
        err = p.stderr if not binary else p.stderr.decode('utf-8', 'replace')
        raise RuntimeError(f'{argv[0]} exit={p.returncode}: {err[-1500:]}')
    return p.stdout


def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1<<20),b''): h.update(block)
    return h.hexdigest()


def adts_hash(path):
    data=cmd(['ffmpeg','-v','error','-i',str(path),'-map','0:a:0','-c:a','copy','-f','adts','-'],binary=True)
    return hashlib.sha256(data).hexdigest()


def probe(path):
    d=json.loads(cmd(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))
    v=[s for s in d['streams'] if s['codec_type']=='video']
    a=[s for s in d['streams'] if s['codec_type']=='audio']
    if len(v)!=1 or len(a)!=1 or len(d['streams'])!=2: raise ValueError('require exactly one video and one audio stream')
    if (v[0]['codec_name'],v[0]['width'],v[0]['height'],v[0]['avg_frame_rate'])!=('h264',1080,1920,'30/1'):
        raise ValueError('require H264 1080x1920 30fps')
    if (a[0]['codec_name'],a[0]['sample_rate'],a[0].get('tags',{}).get('language'))!=('aac','48000','jpn'):
        raise ValueError('require AAC 48kHz with jpn language tag')
    return {'frames':int(v[0]['nb_frames']),'duration':float(d['format']['duration'])}


def validate(m, source_hash, spec):
    if set(m)!={'policy','asset_approval','source_sha256','genre','roi','stages'}:
        raise ValueError('manifest missing or unexpected fields')
    if m['policy']!=POLICY or m['asset_approval']!='private_review_only' or m['source_sha256']!=source_hash:
        raise ValueError('fail-closed approval/hash mismatch')
    if m['genre'] not in GENRES: raise ValueError('unsupported genre')
    if m['roi']!=list(ROI): raise ValueError('ROI must be audited content-only area')
    if not isinstance(m['stages'],list) or len(m['stages'])!=2: raise ValueError('exactly two stages required')
    last=0
    for s in m['stages']:
        if set(s)!={'start_frame','end_frame','column','formula','values','total','target'}:
            raise ValueError('invalid stage keys')
        st,en=s['start_frame'],s['end_frame']
        if type(st)!=int or type(en)!=int or not (180<=st<en<=225 and en<spec['frames'] and st>=last):
            raise ValueError('unsafe frame window')
        last=en
        col=s['column']
        if not isinstance(col,str) or not re.fullmatch('[A-Z]',col): raise ValueError('invalid column')
        if s['formula']!=f'=SUM({col}2:{col}4)': raise ValueError('formula/cell mismatch')
        vals=s['values']
        if not isinstance(vals,list) or len(vals)!=3 or any(type(v)!=int or v<0 or v>9999 for v in vals):
            raise ValueError('invalid source values')
        if type(s['total'])!=int or sum(vals)!=s['total']: raise ValueError('arithmetic mismatch')
        if not isinstance(s['target'],list) or len(s['target'])!=2 or any(type(v)!=int for v in s['target']):
            raise ValueError('invalid target')
        x,y=s['target']
        if not (250<=x<=560 and 710<=y<=800): raise ValueError('target crosses audited selected-cell area')
    if m['stages'][0]['column']==m['stages'][1]['column']:
        raise ValueError('duplicate column stage')
    return m['stages']


def frame_overlay(stage, frame):
    """Transparent frame, only spreadsheet header/selected-cell and blank inner margin."""
    ox,oy,w,h=ROI
    im=Image.new('RGBA',(w,h),(0,0,0,0));d=ImageDraw.Draw(im)
    st,en=stage['start_frame'],stage['end_frame'];q=(frame-st)/max(1,en-st-1)
    column=stage['column']; vals=stage['values']; total=stage['total']
    # Correct the inherited C-formula label only while B5 is selected.
    if column=='B':
        d.rounded_rectangle((17,37,960,124),radius=13,fill=(3,17,39,255),outline=(36,221,209,255),width=3)
        f=ImageFont.truetype(FONT,29)
        d.text((35,60),f'① 数式：{stage["formula"]}',font=f,fill=(248,251,255,255))
    # Highlight the source cell and make the arithmetic proof legible at a glance.
    tx,ty=stage['target'];cx=tx-ox;cy=ty-oy
    pulse=0.5-0.5*math.cos(2*math.pi*q)
    alpha=int(130+105*pulse)
    radius=int(2+3*pulse)
    d.rounded_rectangle((cx-91-radius,cy-39-radius,cx+91+radius,cy+39+radius),radius=9,outline=(61,247,216,alpha),width=4)
    
    # Badge in unused dark region below spreadsheet, not on narration captions.
    bx,by=390,666
    d.rounded_rectangle((bx,by,bx+510,by+59),radius=13,fill=(3,19,42,237),outline=(31,209,194,220),width=2)
    text=f'{column}列  {vals[0]} + {vals[1]} + {vals[2]} = {total}'
    d.text((bx+17,by+8),text,font=ImageFont.truetype(FONT_REG,28),fill=(255,255,255,255))
    # Small progress line, visibly animates from source arithmetic to result.
    d.rounded_rectangle((bx+16,by+50,bx+490,by+54),radius=2,fill=(27,64,78,220))
    d.rounded_rectangle((bx+16,by+50,bx+16+int(474*q),by+54),radius=2,fill=(53,236,205,255))
    return im


def render(source,output,manifest,report):
    source=Path(source);output=Path(output)
    spec=probe(source); stages=validate(manifest,sha256(source),spec)
    output.parent.mkdir(parents=True,exist_ok=True)
    start=stages[0]['start_frame'];end=stages[-1]['end_frame']
    with tempfile.TemporaryDirectory(prefix='lineage_focus_') as td:
        td=Path(td)
        # One transparent sequence with exact frame offset; never upload source media.
        for fr in range(start,end+1):
            s=next((s for s in stages if s['start_frame']<=fr<s['end_frame']),None)
            im=frame_overlay(s,fr) if s else Image.new('RGBA',(ROI[2],ROI[3]),(0,0,0,0))
            im.save(td/f'overlay_{fr-start:03d}.png',compress_level=2)
        cmd(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source),
             '-itsoffset',f'{start/30:.9f}','-framerate','30','-start_number','0',
             '-i',str(td/'overlay_%03d.png'),
             '-filter_complex',f'[0:v][1:v]overlay=x={ROI[0]}:y={ROI[1]}:eof_action=pass:repeatlast=0:format=auto[v]',
             '-map','[v]','-map','0:a:0','-frames:v',str(spec['frames']),
             '-c:v','libx264','-preset','veryfast','-crf','17','-pix_fmt','yuv420p',
             '-c:a','copy','-metadata:s:a:0','language=jpn','-movflags','+faststart',str(output)])
    final=probe(output)
    if final['frames']!=spec['frames'] or abs(final['duration']-spec['duration'])>0.04:
        raise RuntimeError('duration/frame regression')
    cmd(['ffmpeg','-v','error','-i',str(output),'-f','null','-'])
    a0,a1=adts_hash(source),adts_hash(output)
    if a0!=a1:raise RuntimeError('narration audio changed')
    result={'policy':POLICY,'source_sha256':sha256(source),'output_sha256':sha256(output),
            'frames':final['frames'],'duration':final['duration'],'resolution':[1080,1920],
            'fps':30,'stages':stages,'source_audio_adts_sha256':a0,'output_audio_adts_sha256':a1,
            'full_decode':'PASS','caption_region':'NOT_MODIFIED_BY_OVERLAY; visual comparison required',
            'speech_caption_semantics':'NOT_VERIFIED_NO_OFFLINE_ASR','phone_playback':'NOT_VERIFIED',
            'publication':'NOT_APPROVED'}
    Path(report).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ('source','output','manifest','report'):p.add_argument('--'+k,required=True)
    a=p.parse_args()
    print(json.dumps(render(a.source,a.output,json.loads(Path(a.manifest).read_text(encoding='utf-8')),a.report),ensure_ascii=False,indent=2))
