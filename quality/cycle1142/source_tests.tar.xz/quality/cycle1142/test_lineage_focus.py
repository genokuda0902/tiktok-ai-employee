import copy
import hashlib
import os
import tempfile
import unittest
from pathlib import Path
from lineage_focus import GENRES, POLICY, ROI, frame_overlay, probe, render, validate

HASH='a'*64
SPEC={'frames':691,'duration':23.033333}

def fixture(genre='ai'):
    return {'policy':POLICY,'asset_approval':'private_review_only','source_sha256':HASH,
            'genre':genre,'roi':list(ROI),'stages':[
            {'start_frame':182,'end_frame':207,'column':'B','formula':'=SUM(B2:B4)',
             'values':[12,16,18],'total':46,'target':[338,755]},
            {'start_frame':207,'end_frame':218,'column':'C','formula':'=SUM(C2:C4)',
             'values':[8,9,12],'total':29,'target':[505,755]}]}

class Validation(unittest.TestCase):
    def test_all_ten_genres(self):
        for g in GENRES:
            with self.subTest(g=g): self.assertEqual(len(validate(fixture(g),HASH,SPEC)),2)
    def test_reject_missing_asset_approval(self):
        m=fixture();m.pop('asset_approval')
        with self.assertRaises(ValueError):validate(m,HASH,SPEC)
    def test_reject_publication_claim(self):
        m=fixture();m['policy']='APPROVED'
        with self.assertRaises(ValueError):validate(m,HASH,SPEC)
    def test_reject_source_hash_mismatch(self):
        with self.assertRaises(ValueError):validate(fixture(),'b'*64,SPEC)
    def test_reject_formula_column_mismatch(self):
        m=fixture();m['stages'][0]['formula']='=SUM(C2:C4)'
        with self.assertRaises(ValueError):validate(m,HASH,SPEC)
    def test_reject_wrong_total(self):
        m=fixture();m['stages'][0]['total']=45
        with self.assertRaises(ValueError):validate(m,HASH,SPEC)
    def test_reject_wrong_source_values(self):
        m=fixture();m['stages'][1]['values']=[8,9,-12]
        with self.assertRaises(ValueError):validate(m,HASH,SPEC)
    def test_reject_unsafe_roi(self):
        m=fixture();m['roi']=[55,1300,970,800]
        with self.assertRaises(ValueError):validate(m,HASH,SPEC)
    def test_reject_out_of_bounds_target(self):
        m=fixture();m['stages'][0]['target']=[1000,1500]
        with self.assertRaises(ValueError):validate(m,HASH,SPEC)
    def test_reject_overlapping_stages(self):
        m=fixture();m['stages'][1]['start_frame']=206
        with self.assertRaises(ValueError):validate(m,HASH,SPEC)
    def test_reject_duplicate_column(self):
        m=fixture();m['stages'][1]['column']='B';m['stages'][1]['formula']='=SUM(B2:B4)'
        with self.assertRaises(ValueError):validate(m,HASH,SPEC)
    def test_rendered_overlay_is_cropped_and_transparent(self):
        s=fixture()['stages'][0];im=frame_overlay(s,193)
        self.assertEqual(im.size,(ROI[2],ROI[3]))
        self.assertEqual(im.getpixel((0,0))[3],0)
        self.assertEqual(im.getpixel((100,500))[3],0)
        self.assertGreater(im.getpixel((50,75))[3],200)
        self.assertGreater(im.getpixel((500,695))[3],0)
    @unittest.skipUnless(os.environ.get('RUN_MEDIA_SMOKE')=='1','RUN_MEDIA_SMOKE=1 required')
    def test_synthetic_av_render(self):
        import json
        import subprocess
        with tempfile.TemporaryDirectory() as td:
            src=Path(td)/'synthetic.mp4';out=Path(td)/'rendered.mp4';qa=Path(td)/'qa.json'
            subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=0x071827:s=1080x1920:r=30:d=8',
                            '-f','lavfi','-i','sine=frequency=500:sample_rate=48000:duration=8',
                            '-c:v','libx264','-preset','ultrafast','-crf','31','-pix_fmt','yuv420p',
                            '-c:a','aac','-b:a','96k','-metadata:s:a:0','language=jpn','-shortest',str(src)],check=True)
            m=fixture();m['source_sha256']=hashlib.sha256(src.read_bytes()).hexdigest()
            q=render(src,out,m,qa)
            self.assertEqual(q['frames'],240)
            self.assertEqual(q['source_audio_adts_sha256'],q['output_audio_adts_sha256'])
            self.assertTrue(out.is_file() and out.stat().st_size>10000)

if __name__=='__main__':unittest.main()
